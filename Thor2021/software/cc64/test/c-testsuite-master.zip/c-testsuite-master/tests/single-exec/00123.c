double x = 100.0;

int
main()
{
	return x < 1;
}
