
typedef struct  { int n; } Vec;

static void
vecresize(Vec *v, int cap)
{
	return;
}

int main()
{
	return 0;
}
