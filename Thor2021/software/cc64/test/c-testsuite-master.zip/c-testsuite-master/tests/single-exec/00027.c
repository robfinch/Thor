int
main()
{
	int x;
	
	x = 1;
	x = x | 4;
	return x - 5;
}

