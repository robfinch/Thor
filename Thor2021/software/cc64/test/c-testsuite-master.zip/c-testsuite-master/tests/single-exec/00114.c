int main(void);

int
main()
{
	return 0;
}
