int
main()
{
	return L'\0';
}
