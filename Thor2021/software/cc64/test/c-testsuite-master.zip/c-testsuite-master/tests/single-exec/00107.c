typedef int myint;
myint x = (myint)1;

int
main(void)
{
	return x-1;
}
