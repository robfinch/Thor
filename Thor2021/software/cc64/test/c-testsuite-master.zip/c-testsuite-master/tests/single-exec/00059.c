int
main()
{
	if ('a' != 97)
		return 1;
		
	return 0;
}
