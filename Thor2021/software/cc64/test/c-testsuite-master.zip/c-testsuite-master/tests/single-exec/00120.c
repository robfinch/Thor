struct {
	enum { X } x;
} s;


int
main()
{
	return X;
}
