int
main()
{
	int x;
	int y;
	x = y = 0;
	return x;
}
