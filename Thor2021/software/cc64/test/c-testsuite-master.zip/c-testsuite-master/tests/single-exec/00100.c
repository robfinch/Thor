int
foo(void)
{
	return 0;
}

int
main()
{
	return foo();
}
