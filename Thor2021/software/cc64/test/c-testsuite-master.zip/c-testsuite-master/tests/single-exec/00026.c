int
main()
{
	char *p;
	
	p = "hello";
	return p[0] - 104;
}
