#define ADD(X, Y) (X + Y)


int
main()
{
	return ADD(1, 2) - 3;
}
