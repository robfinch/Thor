extern int x;

int main()
{
	return 0;
}
