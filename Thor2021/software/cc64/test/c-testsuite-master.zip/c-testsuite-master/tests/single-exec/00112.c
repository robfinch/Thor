int
main()
{
	return "abc" == (void *)0;
}
